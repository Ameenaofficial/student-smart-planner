package edu.college.planner.model;

public enum Priority {
    LOW, MEDIUM, HIGH
}
