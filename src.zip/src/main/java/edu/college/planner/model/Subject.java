package edu.college.planner.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

@Entity
@Table(uniqueConstraints = @UniqueConstraint(columnNames = {"user_id", "name"}))
public class Subject {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @NotBlank @Size(max = 80)
    @Column(nullable = false, length = 80)
    private String name;
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "user_id", nullable = false)
    private StudentUser owner;
    @OneToOne(mappedBy = "subject", cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.LAZY)
    private Attendance attendance;

    protected Subject() {}
    public Subject(String name, StudentUser owner) { this.name = name.trim(); this.owner = owner; }
    public Long getId() { return id; }
    public String getName() { return name; }
    public StudentUser getOwner() { return owner; }
    public Attendance getAttendance() { return attendance; }
    public void setName(String name) { this.name = name.trim(); }
    public void setAttendance(Attendance attendance) { this.attendance = attendance; }
}
