package edu.college.planner.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

import java.time.LocalDate;

@Entity
public class StudyTask {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @NotBlank @Size(max = 140)
    @Column(nullable = false, length = 140)
    private String title;
    @Size(max = 80) @Column(length = 80)
    private String subject;
    @NotNull @Column(nullable = false)
    private LocalDate dueDate;
    @NotNull @Enumerated(EnumType.STRING) @Column(nullable = false, length = 12)
    private Priority priority = Priority.MEDIUM;
    @Column(nullable = false)
    private boolean completed;
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "user_id", nullable = false)
    private StudentUser owner;

    public StudyTask() {}
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getTitle() { return title; }
    public String getSubject() { return subject; }
    public LocalDate getDueDate() { return dueDate; }
    public Priority getPriority() { return priority; }
    public boolean isCompleted() { return completed; }
    public StudentUser getOwner() { return owner; }
    public void setTitle(String title) { this.title = title; }
    public void setSubject(String subject) { this.subject = subject; }
    public void setDueDate(LocalDate dueDate) { this.dueDate = dueDate; }
    public void setPriority(Priority priority) { this.priority = priority; }
    public void setCompleted(boolean completed) { this.completed = completed; }
    public void setOwner(StudentUser owner) { this.owner = owner; }
}
