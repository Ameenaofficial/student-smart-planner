package edu.college.planner.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.Min;

@Entity
public class Attendance {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @OneToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "subject_id", nullable = false, unique = true)
    private Subject subject;
    @Min(0) @Column(nullable = false)
    private int classesAttended;
    @Min(0) @Column(nullable = false)
    private int totalClasses;

    protected Attendance() {}
    public Attendance(Subject subject, int classesAttended, int totalClasses) {
        this.subject = subject;
        update(classesAttended, totalClasses);
    }
    public Long getId() { return id; }
    public Subject getSubject() { return subject; }
    public int getClassesAttended() { return classesAttended; }
    public int getTotalClasses() { return totalClasses; }
    public double getPercentage() {
        return totalClasses == 0 ? 0.0 : (classesAttended * 100.0) / totalClasses;
    }
    public boolean isBelowThreshold() { return totalClasses > 0 && getPercentage() < 75.0; }
    public void update(int attended, int total) {
        if (attended < 0 || total < 0 || attended > total) {
            throw new IllegalArgumentException("Attended classes must be between zero and total classes.");
        }
        this.classesAttended = attended;
        this.totalClasses = total;
    }
}
