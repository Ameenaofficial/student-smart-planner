package edu.college.planner.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

import java.time.LocalTime;

@Entity
public class ClassSchedule {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @NotBlank @Size(max = 80)
    @Column(nullable = false, length = 80)
    private String subject;
    @Enumerated(EnumType.STRING) @NotNull @Column(name = "class_day", nullable = false, length = 12)
    private WeekDay day;
    @NotNull @Column(nullable = false)
    private LocalTime startTime;
    @NotNull @Column(nullable = false)
    private LocalTime endTime;
    @Size(max = 60) @Column(length = 60)
    private String classroom;
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "user_id", nullable = false)
    private StudentUser owner;

    public ClassSchedule() {}
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getSubject() { return subject; }
    public WeekDay getDay() { return day; }
    public LocalTime getStartTime() { return startTime; }
    public LocalTime getEndTime() { return endTime; }
    public String getClassroom() { return classroom; }
    public StudentUser getOwner() { return owner; }
    public void setSubject(String subject) { this.subject = subject; }
    public void setDay(WeekDay day) { this.day = day; }
    public void setStartTime(LocalTime startTime) { this.startTime = startTime; }
    public void setEndTime(LocalTime endTime) { this.endTime = endTime; }
    public void setClassroom(String classroom) { this.classroom = classroom; }
    public void setOwner(StudentUser owner) { this.owner = owner; }
}
