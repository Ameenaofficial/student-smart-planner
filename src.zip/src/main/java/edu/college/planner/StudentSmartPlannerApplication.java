package edu.college.planner;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StudentSmartPlannerApplication {
    public static void main(String[] args) {
        SpringApplication.run(StudentSmartPlannerApplication.class, args);
    }
}
