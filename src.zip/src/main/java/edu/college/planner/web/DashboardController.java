package edu.college.planner.web;

import edu.college.planner.model.Attendance;
import edu.college.planner.model.StudentUser;
import edu.college.planner.repository.*;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.time.LocalDate;
import java.util.List;

@Controller
public class DashboardController {
    private final AssignmentRepository assignments;
    private final SubjectRepository subjects;
    private final StudyTaskRepository tasks;

    public DashboardController(AssignmentRepository assignments, SubjectRepository subjects, StudyTaskRepository tasks) {
        this.assignments = assignments;
        this.subjects = subjects;
        this.tasks = tasks;
    }

    @GetMapping("/dashboard")
    public String dashboard(@AuthenticationPrincipal StudentUser user, Model model) {
        var allSubjects = subjects.findAllByOwnerIdOrderByNameAsc(user.getId());
        int attended = allSubjects.stream().map(edu.college.planner.model.Subject::getAttendance)
                .filter(java.util.Objects::nonNull).mapToInt(Attendance::getClassesAttended).sum();
        int total = allSubjects.stream().map(edu.college.planner.model.Subject::getAttendance)
                .filter(java.util.Objects::nonNull).mapToInt(Attendance::getTotalClasses).sum();
        model.addAttribute("student", user);
        model.addAttribute("totalAssignments", assignments.countByOwnerId(user.getId()));
        model.addAttribute("pendingAssignments", assignments.countByOwnerIdAndCompletedFalse(user.getId()));
        model.addAttribute("completedAssignments", assignments.countByOwnerIdAndCompletedTrue(user.getId()));
        model.addAttribute("attendancePercent", total == 0 ? 0 : Math.round(attended * 100.0 / total));
        model.addAttribute("attendanceSubjects", allSubjects);
        model.addAttribute("upcoming", assignments.findTop5ByOwnerIdAndCompletedFalseAndDueDateGreaterThanEqualOrderByDueDateAsc(user.getId(), LocalDate.now()));
        model.addAttribute("todayTasks", tasks.findAllByOwnerIdAndDueDateAndCompletedFalseOrderByPriorityDesc(user.getId(), LocalDate.now()));
        List<?> recentTasks = tasks.findAllByOwnerIdOrderByDueDateAsc(user.getId());
        model.addAttribute("taskCount", recentTasks.size());
        model.addAttribute("doneTasks", tasks.countByOwnerIdAndCompletedTrue(user.getId()));
        return "dashboard";
    }
}
