package edu.college.planner.config;

import edu.college.planner.model.*;
import edu.college.planner.repository.*;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.time.LocalDate;
import java.time.LocalTime;

@Configuration
@Profile("demo")
public class DemoDataConfig {
    @Bean
    CommandLineRunner seedDemoData(StudentUserRepository users, AssignmentRepository assignments,
                                   SubjectRepository subjects, ClassScheduleRepository schedules,
                                   StudyTaskRepository tasks, PasswordEncoder encoder) {
        return args -> {
            if (users.existsByEmailIgnoreCase("student@example.com")) return;
            StudentUser user = users.save(new StudentUser("Alex Morgan", "student@example.com", encoder.encode("Student@123")));

            Assignment database = new Assignment();
            database.setTitle("ER diagram and schema");
            database.setSubject("Database Systems");
            database.setDescription("Prepare the ER model and normalize the sample database.");
            database.setDueDate(LocalDate.now().plusDays(2));
            database.setPriority(Priority.HIGH);
            database.setOwner(user);
            assignments.save(database);

            Assignment writing = new Assignment();
            writing.setTitle("Research summary");
            writing.setSubject("Technical Writing");
            writing.setDescription("Summarize two journal articles.");
            writing.setDueDate(LocalDate.now().plusDays(5));
            writing.setPriority(Priority.MEDIUM);
            writing.setOwner(user);
            assignments.save(writing);

            Subject math = new Subject("Discrete Mathematics", user);
            math.setAttendance(new Attendance(math, 17, 20));
            subjects.save(math);
            Subject networks = new Subject("Computer Networks", user);
            networks.setAttendance(new Attendance(networks, 12, 18));
            subjects.save(networks);

            ClassSchedule classSchedule = new ClassSchedule();
            classSchedule.setSubject("Discrete Mathematics");
            classSchedule.setDay(WeekDay.MONDAY);
            classSchedule.setStartTime(LocalTime.of(9, 0));
            classSchedule.setEndTime(LocalTime.of(10, 0));
            classSchedule.setClassroom("Room 204");
            classSchedule.setOwner(user);
            schedules.save(classSchedule);

            StudyTask task = new StudyTask();
            task.setTitle("Review graph theory notes");
            task.setSubject("Discrete Mathematics");
            task.setDueDate(LocalDate.now());
            task.setPriority(Priority.HIGH);
            task.setOwner(user);
            tasks.save(task);
        };
    }
}
