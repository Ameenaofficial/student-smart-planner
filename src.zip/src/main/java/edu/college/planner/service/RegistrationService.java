package edu.college.planner.service;

import edu.college.planner.model.StudentUser;
import edu.college.planner.repository.StudentUserRepository;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class RegistrationService {
    private final StudentUserRepository users;
    private final PasswordEncoder passwordEncoder;

    public RegistrationService(StudentUserRepository users, PasswordEncoder passwordEncoder) {
        this.users = users;
        this.passwordEncoder = passwordEncoder;
    }

    @Transactional
    public StudentUser register(String name, String email, String password) {
        String normalizedEmail = email.trim().toLowerCase();
        if (users.existsByEmailIgnoreCase(normalizedEmail)) {
            throw new IllegalArgumentException("An account with this email already exists.");
        }
        return users.save(new StudentUser(name.trim(), normalizedEmail, passwordEncoder.encode(password)));
    }
}
