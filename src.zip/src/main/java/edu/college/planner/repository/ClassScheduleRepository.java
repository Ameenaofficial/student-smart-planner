package edu.college.planner.repository;

import edu.college.planner.model.ClassSchedule;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface ClassScheduleRepository extends JpaRepository<ClassSchedule, Long> {
    List<ClassSchedule> findAllByOwnerIdOrderByDayAscStartTimeAsc(Long ownerId);
    Optional<ClassSchedule> findByIdAndOwnerId(Long id, Long ownerId);
}
