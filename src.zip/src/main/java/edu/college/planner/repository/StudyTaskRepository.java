package edu.college.planner.repository;

import edu.college.planner.model.StudyTask;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

public interface StudyTaskRepository extends JpaRepository<StudyTask, Long> {
    List<StudyTask> findAllByOwnerIdOrderByDueDateAsc(Long ownerId);
    Optional<StudyTask> findByIdAndOwnerId(Long id, Long ownerId);
    List<StudyTask> findAllByOwnerIdAndDueDateAndCompletedFalseOrderByPriorityDesc(Long ownerId, LocalDate dueDate);
    long countByOwnerIdAndCompletedTrue(Long ownerId);
}
