package edu.college.planner.repository;

import edu.college.planner.model.Assignment;
import edu.college.planner.model.Priority;
import edu.college.planner.model.StudentUser;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.assertEquals;

@DataJpaTest
class AssignmentRepositoryTest {
    @Autowired private StudentUserRepository users;
    @Autowired private AssignmentRepository assignments;

    @Test
    void onlyReturnsAssignmentsForTheRequestedStudent() {
        StudentUser first = users.save(new StudentUser("First Student", "first@example.com", "encoded"));
        StudentUser second = users.save(new StudentUser("Second Student", "second@example.com", "encoded"));
        assignments.save(assignment("First student's work", first));
        assignments.save(assignment("Second student's work", second));

        var firstAssignments = assignments.findAllByOwnerIdOrderByDueDateAsc(first.getId());
        var secondAssignments = assignments.findAllByOwnerIdOrderByDueDateAsc(second.getId());

        assertEquals(1, firstAssignments.size());
        assertEquals("First student's work", firstAssignments.get(0).getTitle());
        assertEquals(1, secondAssignments.size());
        assertEquals("Second student's work", secondAssignments.get(0).getTitle());
    }

    private Assignment assignment(String title, StudentUser owner) {
        Assignment assignment = new Assignment();
        assignment.setTitle(title);
        assignment.setSubject("Test subject");
        assignment.setDueDate(LocalDate.now().plusDays(1));
        assignment.setPriority(Priority.MEDIUM);
        assignment.setOwner(owner);
        return assignment;
    }
}
