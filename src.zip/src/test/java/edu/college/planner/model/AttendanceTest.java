package edu.college.planner.model;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class AttendanceTest {
    private Attendance attendance(int attended, int total) {
        StudentUser user = new StudentUser("Test Student", "test@example.com", "hashed");
        Subject subject = new Subject("Mathematics", user);
        return new Attendance(subject, attended, total);
    }

    @Test
    void calculatesPercentageAndBoundaryCorrectly() {
        Attendance attendance = attendance(15, 20);
        assertEquals(75.0, attendance.getPercentage());
        assertFalse(attendance.isBelowThreshold());
    }

    @Test
    void warnsBelowSeventyFivePercent() {
        Attendance attendance = attendance(14, 20);
        assertEquals(70.0, attendance.getPercentage());
        assertTrue(attendance.isBelowThreshold());
    }

    @Test
    void zeroClassesHasZeroPercentWithoutDivisionError() {
        Attendance attendance = attendance(0, 0);
        assertEquals(0.0, attendance.getPercentage());
        assertFalse(attendance.isBelowThreshold());
    }

    @Test
    void rejectsImpossibleAttendanceCounts() {
        StudentUser user = new StudentUser("Test Student", "test@example.com", "hashed");
        Subject subject = new Subject("Mathematics", user);
        assertThrows(IllegalArgumentException.class, () -> new Attendance(subject, 5, 4));
    }
}
